package romeo.springthymeleafcrud.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import romeo.springthymeleafcrud.model.Produto;


public interface ProdutoRepository extends JpaRepository<Produto, Integer> {
}
